const express = require('express');
const router = express.Router();

// Import guardController
const guardController = require('../controllers/guardController');

// Define routes using guardController
router.get('/guards', guardController.guards);
router.get('/guard/:id', guardController.guard);
router.get('/search/guard', guardController.searchGuard);
router.get('/delete/:id', guardController.deleteGuard);
module.exports = router;
