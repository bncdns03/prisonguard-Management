const guards = [
    {
        'id': 1,
        'name': 'Nico',
        'age': 60,
        'rank': 'Sergeant',
        'years of service': '19 years',
    },
    {
        'id': 2,
        'name': 'Rovic',
        'age': 99,
        'rank': 'Captain',
        'years of service': '20 years',
    },
    {
        'id': 3,
        'name': 'Chance',
        'age': 50,
        'rank': 'Lieutenant',
        'years of service': '21 years',
    }
];

module.exports.guards = (req, res) => {
    res.json ({'GUARDS': guards});

};

//search a prisoner by using /prisoner/ {id}
//method name must be prisoner

module.exports.guard = (req, res) => {
    const { id } = req.params;
    console.log(id);
    const matchingGuard = guards.find(guard => guard.id === parseInt(id));
    if (!matchingGuard) {
        res.status(404).json({ 'error': `Guard with ID ${id} not found` });
    } else {
        res.status(200).json({ 'guard': matchingGuard });
    }
};


module.exports.greet = (req, res) => { 
    const { name } = req.query
    console.log(name)
    res.status(200).json({'hello':name})
}

// using multiple queries
// route: /search/prisoner?key1=value1&key2=value2
//e.g /search/prisoner?id=1&name=bianca
module.exports.searchGuard = (req, res) => {
    const { id, rank, yearsOfService } = req.query;
    console.log(id, rank, yearsOfService);

    // Filter guards based on the provided criteria
    const matchingGuards = guards.reduce((acc, guard) => {
        // Check if the guard matches the provided ID (if provided)
        if (id && guard.id !== parseInt(id)) {
            return acc;
        }
        // Check if the guard matches the provided rank (if provided)
        if (rank && guard.rank.toLowerCase() !== rank.toLowerCase()) {
            return acc;
        }
        // Check if the guard matches the provided years of service (if provided)
        if (yearsOfService && parseInt(guard['years of service']) !== parseInt(yearsOfService)) {
            return acc;
        }
        // If all criteria match or are not provided, include the guard
        return [...acc, guard];
    }, []);

    // Check if any guards match the criteria
    if (matchingGuards.length === 0) {
        res.status(404).json({ 'error': `No guards found with the specified criteria` });
    } else {
        res.status(200).json({ 'found': matchingGuards });
    }
};

module.exports.deleteGuard = (req, res) => {
    const { id } = req.params;
    console.log(id);
    
    // Find the index of the guard with the provided ID
    const index = guards.findIndex(guard => guard.id === parseInt(id));
    
    // Check if a guard with the provided ID exists
    if (index === -1) {
        res.status(404).json({ 'error': `Guard with ID ${id} not found` });
    } else {
        // Remove the guard from the array
        const deleteGuard = guards[index];
        guards.splice(index, 1);
        res.status(200).json({ 'message': `Guard with ID ${id} has been deleted` });
    }
};


