const prisoners = [
    {
        'id' : 1,
        'name': 'Carl',
        'age': 22,
        'crime': 'Possesion of Illegal Drugs',
        'sentence': '15 years',
    },
    {
        'id' : 2,
        'name': 'Bianca',
        'age': 21,
        'crime': 'Serial Murder',
        'sentence': '30 years',
    },
    {
        'id' : 3,
        'name': 'Arabella',
        'age': 19,
        'crime': 'Adultery',
        'sentence': '10 years',
    }
];

module.exports.prisoners = (req, res) => {
    res.json ({'PRISONERS': prisoners});
};

// Search a prisoner by using /prisoner/ {id}
// Method name must be prisoner
module.exports.prisoner = (req, res) => {
    const {id} = req.params;
    console.log(id);
    const matchingPrisoner = prisoners.filter (
        (prisoner) => prisoner.id === parseInt(id)
    );
    if (matchingPrisoner.length === 0) {
        res.status(404).json({'error': `Prisoner with ID ${id} not found`});
    } else {
        res.status(200).json({'prisoner': matchingPrisoner[0]});
    } 
};

module.exports.greet = (req, res) => { 
    const { name } = req.query;
    console.log(name);
    res.status(200).json({'hello': name});
};

// Using multiple queries
// Route: /search/prisoner?key1=value1&key2=value2
// e.g /search/prisoner?id=1&name=bianca
module.exports.searchPrisoner = (req, res) => {
    const {id, name} = req.query;
    console.log(id, name);
    const matchingPrisoner = prisoners.filter(
        (p) => p.id === parseInt(id) && p.name === name
    );
    if (matchingPrisoner.length === 0) {
        res.status(404).json({'error': `Prisoner with ID ${id} and name ${name} not found`});
    } else {
        res.status(200).json({'found': matchingPrisoner[0]});
    }
};
